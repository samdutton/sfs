// document.body.onkeydown = function(event){
// 	chrome.extension.sendMessage({type: "playSound", keyCode: event.keyCode}, function(response) {
// 	//		console.log("response", response);
// 	});
// };

// chrome.extension.sendMessage({type: "hello", }, function(response) {
// 	console.log("response", response);
// });
